-- =============================================================================
-- PROYECTO: Red Social Estudiantil Pascualina (RedUniConnect)
-- CURSO: Bases de Datos 1 (Grupo G100 - ET0057)
-- INSTITUCIÓN: Institución Universitaria Pascual Bravo
-- AUTOR: Alejandro Valencia Jiménez
-- UNIDAD 3 - TAREA 5: Interacción con datos (DML) y Creación de Vistas (Views)
-- ARCHIVO: 01_Borrador_Inicial_DML_Vistas_RedUniConnect.sql
-- SGBD: PostgreSQL 15+ (pgAdmin 4)
-- DESCRIPCIÓN: Borrador inicial del sistema de consultas SQL (DML) y vistas,
--              con identificación de tablas, campos, tipos de datos físicos
--              y aplicación inicial de reglas de nomenclatura para ALIAS.
-- =============================================================================

SET search_path TO red_social_uni;

-- =============================================================================
-- SECCIÓN 1: IDENTIFICACIÓN DE TABLAS, CAMPOS Y TIPOS DE DATOS DEL MODELO FÍSICO
-- =============================================================================
/*
  1. TABLA: red_social_uni.usuarios
     - id_usuario           : BIGSERIAL (PK)
     - nombre_completo      : VARCHAR(120) NOT NULL
     - correo_institucional : VARCHAR(150) NOT NULL UNIQUE
     - password_hash        : VARCHAR(255) NOT NULL
     - programa_academico   : VARCHAR(100) NOT NULL
     - semestre_actual      : SMALLINT NOT NULL (1..12)
     - es_mentor            : BOOLEAN NOT NULL DEFAULT FALSE
     - fecha_registro       : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
     - estado_cuenta        : VARCHAR(20) NOT NULL ('ACTIVO', 'INACTIVO', 'SUSPENDIDO')

  2. TABLA: red_social_uni.perfiles
     - id_perfil                  : BIGSERIAL (PK)
     - id_usuario                 : BIGINT NOT NULL UNIQUE (FK -> usuarios.id_usuario)
     - biografia                  : TEXT NULL
     - avatar_url                 : VARCHAR(255) NULL
     - habilidades_intereses_json : JSONB NOT NULL DEFAULT '{}'::jsonb
     - ultima_actualizacion       : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP

  3. TABLA: red_social_uni.conexiones
     - id_conexion    : BIGSERIAL (PK)
     - id_seguidor    : BIGINT NOT NULL (FK -> usuarios.id_usuario)
     - id_seguido     : BIGINT NOT NULL (FK -> usuarios.id_usuario)
     - tipo_vinculo   : VARCHAR(20) NOT NULL ('PAR', 'MENTORIA')
     - estado_vinculo : VARCHAR(20) NOT NULL ('PENDIENTE', 'ACEPTADO', 'BLOQUEADO')
     - fecha_conexion : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP

  4. TABLA: red_social_uni.publicaciones
     - id_publicacion         : BIGSERIAL (PK)
     - id_autor               : BIGINT NOT NULL (FK -> usuarios.id_usuario)
     - categoria_post         : VARCHAR(30) NOT NULL ('PREGUNTA_TAREA', 'RECURSO_UTIL', 'NOTICIA_TECH', 'MEME')
     - contenido_texto        : TEXT NOT NULL
     - recurso_multimedia_url : VARCHAR(255) NULL
     - fecha_publicacion      : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP

  5. TABLA: red_social_uni.grupos
     - id_grupo       : BIGSERIAL (PK)
     - id_creador     : BIGINT NOT NULL (FK -> usuarios.id_usuario)
     - nombre_grupo   : VARCHAR(100) NOT NULL UNIQUE
     - descripcion    : TEXT NOT NULL
     - tipo_grupo     : VARCHAR(30) NOT NULL ('ESTUDIO_MATERIA', 'EQUIPO_HACKATON', 'CLUB_INTERES')
     - es_privado     : BOOLEAN NOT NULL DEFAULT FALSE
     - fecha_creacion : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP

  6. TABLA: red_social_uni.miembros_grupo
     - id_grupo      : BIGINT NOT NULL (PK, FK -> grupos.id_grupo)
     - id_usuario    : BIGINT NOT NULL (PK, FK -> usuarios.id_usuario)
     - rol_en_grupo  : VARCHAR(20) NOT NULL ('ADMIN', 'MODERADOR', 'MIEMBRO')
     - fecha_ingreso : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP

  7. TABLA: red_social_uni.eventos
     - id_evento           : BIGSERIAL (PK)
     - id_grupo            : BIGINT NULL (FK -> grupos.id_grupo)
     - id_organizador      : BIGINT NOT NULL (FK -> usuarios.id_usuario)
     - titulo_evento       : VARCHAR(150) NOT NULL
     - descripcion_evento  : TEXT NOT NULL
     - modalidad_evento    : VARCHAR(25) NOT NULL ('REUNION_ESTUDIO', 'TALLER', 'ACTIVIDAD_SOCIAL', 'HACKATON')
     - ubicacion_aula      : VARCHAR(120) NOT NULL
     - fecha_hora_inicio   : TIMESTAMPTZ NOT NULL
     - fecha_hora_fin      : TIMESTAMPTZ NOT NULL
     - telemetria_iot_json : JSONB NULL

  8. TABLA: red_social_uni.asistentes_evento
     - id_evento            : BIGINT NOT NULL (PK, FK -> eventos.id_evento)
     - id_usuario           : BIGINT NOT NULL (PK, FK -> usuarios.id_usuario)
     - estado_participacion : VARCHAR(20) NOT NULL ('INTERESADO', 'CONFIRMADO', 'ASISTIO', 'CANCELADO')
     - fecha_inscripcion    : TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP

  REGLAS DE NOMENCLATURA PARA ALIAS DE DATOS CALCULADOS (BORRADOR):
  - Formato estándar: snake_case en minúsculas, sin espacios ni tildes.
  - Prefijos semánticos según el cálculo:
    * total_<entidad>        : Conteos con COUNT() o sumatorias con SUM().
    * promedio_<metrica>     : Promedios aritméticos con AVG().
    * porcentaje_<metrica>   : Proporciones expresadas en escala 0..100.
    * dias_<evento>          : Diferencias temporales expresadas en días.
    * duracion_<unidad>      : Intervalos de tiempo calculados entre fechas.
    * clasificacion_<criterio>: Categorizaciones derivadas con CASE WHEN.
*/

-- =============================================================================
-- SECCIÓN 2: INSERCIÓN INICIAL DE DATOS DE PRUEBA (DML - INSERT)
-- =============================================================================

INSERT INTO usuarios (nombre_completo, correo_institucional, password_hash, programa_academico, semestre_actual, es_mentor, estado_cuenta)
VALUES
('Alejandro Valencia Jiménez', 'alejandro.valencia@pascualbravo.edu.co', '$2b$12$HashAlejo01', 'Tecnología en Desarrollo de Software', 6, TRUE, 'ACTIVO'),
('Miguel Ángel Restrepo', 'miguel.restrepo@pascualbravo.edu.co', '$2b$12$HashMiguel02', 'Tecnología en Desarrollo de Software', 5, TRUE, 'ACTIVO'),
('Laura Sofía Gómez', 'laura.gomez@pascualbravo.edu.co', '$2b$12$HashLaura03', 'Ingeniería de Software', 2, FALSE, 'ACTIVO'),
('Carlos Andrés Ríos', 'carlos.rios@pascualbravo.edu.co', '$2b$12$HashCarlos04', 'Ingeniería Eléctrica', 7, TRUE, 'ACTIVO'),
('Valentina Morales', 'valentina.morales@pascualbravo.edu.co', '$2b$12$HashValen05', 'Tecnología en Desarrollo de Software', 1, FALSE, 'ACTIVO');

INSERT INTO perfiles (id_usuario, biografia, avatar_url, habilidades_intereses_json)
VALUES
(1, 'Estudiante de Desarrollo de Software apasionado por SQL, C#, C++ y Angular.', 'https://cdn.pascualina.edu.co/avatars/u1.png',
 '{"disciplinas_academicas": ["Bases de Datos", "POO en C#", "Estructuras de Datos"], "lenguajes_tecnologias": ["SQL", "C#", "C++", "Angular"], "deportes_hobbies": ["Polo Acuático", "Ajedrez", "Videojuegos"]}'::jsonb),
(2, 'Desarrollador frontend y entusiasta de algoritmos y fútbol.', 'https://cdn.pascualina.edu.co/avatars/u2.png',
 '{"disciplinas_academicas": ["Desarrollo Web", "Álgebra Lineal"], "lenguajes_tecnologias": ["TypeScript", "Angular", "Python"], "deportes_hobbies": ["Fútbol", "Programación Competitiva"]}'::jsonb),
(3, 'Aprendiendo fundamentos de programación y modelado relacional.', 'https://cdn.pascualina.edu.co/avatars/u3.png',
 '{"disciplinas_academicas": ["Lógica de Programación", "Bases de Datos 1"], "lenguajes_tecnologias": ["Python", "SQL"], "deportes_hobbies": ["Voleibol", "Lectura"]}'::jsonb);

-- =============================================================================
-- SECCIÓN 3: CONSULTAS DML INICIALES CON DATOS CALCULADOS (ALIAS)
-- =============================================================================

-- Consulta Borrador 1: Listado de estudiantes y clasificación por nivel de semestre
SELECT
    u.id_usuario AS codigo_estudiante,
    u.nombre_completo AS nombre_estudiante,
    u.programa_academico AS carrera_actual,
    u.semestre_actual AS numero_semestre,
    CASE
        WHEN u.semestre_actual >= 5 THEN 'Ciclo Avanzado (Elegible Mentor)'
        ELSE 'Ciclo Inicial / Básico'
    END AS clasificacion_nivel_academico,
    EXTRACT(DAY FROM (CURRENT_TIMESTAMP - u.fecha_registro)) AS dias_antiguedad_registro
FROM usuarios u
WHERE u.estado_cuenta = 'ACTIVO';

-- Consulta Borrador 2: Conteo de conexiones y mentorías recibidas por estudiante
SELECT
    u.id_usuario AS id_estudiante_seguido,
    u.nombre_completo AS nombre_mentor_o_par,
    COUNT(c.id_conexion) AS total_conexiones_recibidas,
    SUM(CASE WHEN c.tipo_vinculo = 'MENTORIA' THEN 1 ELSE 0 END) AS total_solicitudes_mentoria
FROM usuarios u
INNER JOIN conexiones c ON u.id_usuario = c.id_seguido
GROUP BY u.id_usuario, u.nombre_completo;

-- Consulta Borrador 3: Total de publicaciones por categoría en el muro
SELECT
    p.categoria_post AS categoria_publicacion,
    COUNT(p.id_publicacion) AS total_publicaciones_registradas,
    COUNT(p.recurso_multimedia_url) AS total_publicaciones_con_enlace
FROM publicaciones p
GROUP BY p.categoria_post
ORDER BY total_publicaciones_registradas DESC;

-- Consulta Borrador 4: Cantidad de integrantes por grupo de estudio o hackatón
SELECT
    g.id_grupo AS identificador_grupo,
    g.nombre_grupo AS nombre_comunidad,
    g.tipo_grupo AS categoria_grupo,
    COUNT(mg.id_usuario) AS total_miembros_inscritos
FROM grupos g
INNER JOIN miembros_grupo mg ON g.id_grupo = mg.id_grupo
GROUP BY g.id_grupo, g.nombre_grupo, g.tipo_grupo;

-- =============================================================================
-- SECCIÓN 4: PRIMER SCRIPT DE CREACIÓN DE VISTAS (BORRADOR INICIAL)
-- =============================================================================

-- Vista Borrador 1: Resumen básico de mentores y sus seguidores
CREATE OR REPLACE VIEW vw_borrador_mentores AS
SELECT
    u.id_usuario AS id_mentor,
    u.nombre_completo AS nombre_mentor,
    u.programa_academico AS programa_estudio,
    u.semestre_actual AS semestre_cursado,
    COUNT(c.id_conexion) AS total_vinculos_activos
FROM usuarios u
LEFT JOIN conexiones c ON u.id_usuario = c.id_seguido AND c.estado_vinculo = 'ACEPTADO'
WHERE u.es_mentor = TRUE
GROUP BY u.id_usuario, u.nombre_completo, u.programa_academico, u.semestre_actual;

-- Vista Borrador 2: Resumen básico de eventos y duración en horas
CREATE OR REPLACE VIEW vw_borrador_eventos AS
SELECT
    e.id_evento AS codigo_evento,
    e.titulo_evento AS nombre_evento,
    e.modalidad_evento AS tipo_modalidad,
    e.ubicacion_aula AS lugar_evento,
    EXTRACT(EPOCH FROM (e.fecha_hora_fin - e.fecha_hora_inicio)) / 3600.0 AS duracion_evento_horas,
    COUNT(ae.id_usuario) AS total_estudiantes_inscritos
FROM eventos e
LEFT JOIN asistentes_evento ae ON e.id_evento = ae.id_evento
GROUP BY e.id_evento, e.titulo_evento, e.modalidad_evento, e.ubicacion_aula, e.fecha_hora_inicio, e.fecha_hora_fin;
