-- =============================================================================
-- PROYECTO: Red Social Estudiantil Pascualina (RedUniConnect)
-- CURSO: Bases de Datos 1 (Grupo G100 - ET0057)
-- INSTITUCIÓN: Institución Universitaria Pascual Bravo
-- AUTOR: Alejandro Valencia Jiménez
-- UNIDAD 3 - TAREA 5: Interacción con datos (DML) y Creación de Vistas (Views)
-- ARCHIVO: 02_Script_Final_DML_Vistas_RedUniConnect.sql
-- SGBD: PostgreSQL 15+ (pgAdmin 4)
-- DESCRIPCIÓN: Versión final ajustada, optimizada y comentada del script DML
--              (INSERT, UPDATE, DELETE, SELECT) y modelo de Vistas Analíticas
--              (CREATE OR REPLACE VIEW) aplicando estándares SQL y reglas de
--              nomenclatura snake_case para datos calculados con ALIAS.
-- =============================================================================

BEGIN;

-- =============================================================================
-- 0. PREÁMBULO DE COMPATIBILIDAD FÍSICA (ESQUEMA UNIDAD 2 - REDUNICONNECT)
-- Garantiza que el script sea 100% autoejecutable en pgAdmin 4 si las tablas
-- aún no han sido creadas en la instancia local.
-- =============================================================================
CREATE SCHEMA IF NOT EXISTS red_social_uni;
SET search_path TO red_social_uni;

CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario BIGSERIAL PRIMARY KEY,
    nombre_completo VARCHAR(120) NOT NULL,
    correo_institucional VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    programa_academico VARCHAR(100) NOT NULL,
    semestre_actual SMALLINT NOT NULL CHECK (semestre_actual BETWEEN 1 AND 12),
    es_mentor BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_registro TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado_cuenta VARCHAR(20) NOT NULL DEFAULT 'ACTIVO'
        CHECK (estado_cuenta IN ('ACTIVO', 'INACTIVO', 'SUSPENDIDO'))
);

CREATE TABLE IF NOT EXISTS perfiles (
    id_perfil BIGSERIAL PRIMARY KEY,
    id_usuario BIGINT NOT NULL UNIQUE,
    biografia TEXT,
    avatar_url VARCHAR(255),
    habilidades_intereses_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    ultima_actualizacion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_perfiles_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conexiones (
    id_conexion BIGSERIAL PRIMARY KEY,
    id_seguidor BIGINT NOT NULL,
    id_seguido BIGINT NOT NULL,
    tipo_vinculo VARCHAR(20) NOT NULL DEFAULT 'PAR'
        CHECK (tipo_vinculo IN ('PAR', 'MENTORIA')),
    estado_vinculo VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE'
        CHECK (estado_vinculo IN ('PENDIENTE', 'ACEPTADO', 'BLOQUEADO')),
    fecha_conexion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_conexiones_seguidor FOREIGN KEY (id_seguidor)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
    CONSTRAINT fk_conexiones_seguido FOREIGN KEY (id_seguido)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
    CONSTRAINT uq_seguidor_seguido UNIQUE (id_seguidor, id_seguido),
    CONSTRAINT chk_no_autoseguimiento CHECK (id_seguidor <> id_seguido)
);

CREATE TABLE IF NOT EXISTS publicaciones (
    id_publicacion BIGSERIAL PRIMARY KEY,
    id_autor BIGINT NOT NULL,
    categoria_post VARCHAR(30) NOT NULL
        CHECK (categoria_post IN ('PREGUNTA_TAREA', 'RECURSO_UTIL', 'NOTICIA_TECH', 'MEME')),
    contenido_texto TEXT NOT NULL,
    recurso_multimedia_url VARCHAR(255),
    fecha_publicacion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_publicaciones_autor FOREIGN KEY (id_autor)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS grupos (
    id_grupo BIGSERIAL PRIMARY KEY,
    id_creador BIGINT NOT NULL,
    nombre_grupo VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT NOT NULL,
    tipo_grupo VARCHAR(30) NOT NULL
        CHECK (tipo_grupo IN ('ESTUDIO_MATERIA', 'EQUIPO_HACKATON', 'CLUB_INTERES')),
    es_privado BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_creacion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_grupos_creador FOREIGN KEY (id_creador)
        REFERENCES usuarios(id_usuario) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS miembros_grupo (
    id_grupo BIGINT NOT NULL,
    id_usuario BIGINT NOT NULL,
    rol_en_grupo VARCHAR(20) NOT NULL DEFAULT 'MIEMBRO'
        CHECK (rol_en_grupo IN ('ADMIN', 'MODERADOR', 'MIEMBRO')),
    fecha_ingreso TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_grupo, id_usuario),
    CONSTRAINT fk_miembros_grupo FOREIGN KEY (id_grupo)
        REFERENCES grupos(id_grupo) ON DELETE CASCADE,
    CONSTRAINT fk_miembros_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS eventos (
    id_evento BIGSERIAL PRIMARY KEY,
    id_grupo BIGINT,
    id_organizador BIGINT NOT NULL,
    titulo_evento VARCHAR(150) NOT NULL,
    descripcion_evento TEXT NOT NULL,
    modalidad_evento VARCHAR(25) NOT NULL
        CHECK (modalidad_evento IN ('REUNION_ESTUDIO', 'TALLER', 'ACTIVIDAD_SOCIAL', 'HACKATON')),
    ubicacion_aula VARCHAR(120) NOT NULL,
    fecha_hora_inicio TIMESTAMPTZ NOT NULL,
    fecha_hora_fin TIMESTAMPTZ NOT NULL,
    telemetria_iot_json JSONB,
    CONSTRAINT fk_eventos_grupo FOREIGN KEY (id_grupo)
        REFERENCES grupos(id_grupo) ON DELETE SET NULL,
    CONSTRAINT fk_eventos_organizador FOREIGN KEY (id_organizador)
        REFERENCES usuarios(id_usuario) ON DELETE RESTRICT,
    CONSTRAINT chk_fechas_evento CHECK (fecha_hora_fin > fecha_hora_inicio)
);

CREATE TABLE IF NOT EXISTS asistentes_evento (
    id_evento BIGINT NOT NULL,
    id_usuario BIGINT NOT NULL,
    estado_participacion VARCHAR(20) NOT NULL DEFAULT 'CONFIRMADO'
        CHECK (estado_participacion IN ('INTERESADO', 'CONFIRMADO', 'ASISTIO', 'CANCELADO')),
    fecha_inscripcion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_evento, id_usuario),
    CONSTRAINT fk_asistentes_evento FOREIGN KEY (id_evento)
        REFERENCES eventos(id_evento) ON DELETE CASCADE,
    CONSTRAINT fk_asistentes_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id_usuario) ON DELETE CASCADE
);

-- Limpieza controlada previa para garantizar idempotencia en pruebas repetidas
TRUNCATE TABLE
    asistentes_evento,
    eventos,
    miembros_grupo,
    grupos,
    publicaciones,
    conexiones,
    perfiles,
    usuarios
RESTART IDENTITY CASCADE;

-- =============================================================================
-- 1. POBLACIÓN DE DATOS TRANSACCIONALES Y DE CATÁLOGO (DML - INSERT)
-- Cubre los 5 ejes funcionales de la Red Social Estudiantil Pascualina:
-- Perfiles, Conexiones/Mentoría, Publicaciones, Grupos y Eventos.
-- =============================================================================

-- 1.1 Inserción de Estudiantes (Tabla: usuarios)
INSERT INTO usuarios (
    nombre_completo, correo_institucional, password_hash,
    programa_academico, semestre_actual, es_mentor, fecha_registro, estado_cuenta
) VALUES
('Alejandro Valencia Jiménez', 'alejandro.valencia@pascualbravo.edu.co', '$2b$12$K9xP01AlejoHashSeg', 'Tecnología en Desarrollo de Software', 6, TRUE,  '2026-02-10 08:30:00-05', 'ACTIVO'),
('Miguel Ángel Restrepo',      'miguel.restrepo@pascualbravo.edu.co',    '$2b$12$K9xP02MiguelHashSeg', 'Tecnología en Desarrollo de Software', 5, TRUE,  '2026-02-12 09:15:00-05', 'ACTIVO'),
('Laura Sofía Gómez',          'laura.gomez@pascualbravo.edu.co',        '$2b$12$K9xP03LauraHashSeg',  'Ingeniería de Software',               2, FALSE, '2026-03-01 10:00:00-05', 'ACTIVO'),
('Carlos Andrés Ríos',         'carlos.rios@pascualbravo.edu.co',        '$2b$12$K9xP04CarlosHashSeg', 'Ingeniería Eléctrica',                 8, TRUE,  '2026-01-20 14:20:00-05', 'ACTIVO'),
('Valentina Morales Cano',     'valentina.morales@pascualbravo.edu.co',  '$2b$12$K9xP05ValenHashSeg',  'Tecnología en Desarrollo de Software', 1, FALSE, '2026-08-05 11:45:00-05', 'ACTIVO'),
('Mateo Montoya Vélez',        'mateo.montoya@pascualbravo.edu.co',      '$2b$12$K9xP06MateoHashSeg',  'Ingeniería de Software',               7, TRUE,  '2026-02-18 16:10:00-05', 'ACTIVO'),
('Sofía Patiño Londoño',       'sofia.patino@pascualbravo.edu.co',       '$2b$12$K9xP07SofiaHashSeg',  'Diseño Gráfico Digital',               4, FALSE, '2026-04-11 13:00:00-05', 'ACTIVO'),
('Daniel Ospina Cardona',      'daniel.ospina@pascualbravo.edu.co',      '$2b$12$K9xP08DanielHashSeg', 'Tecnología en Sistemas Mecatrónicos',  6, TRUE,  '2026-03-22 15:30:00-05', 'ACTIVO'),
('Camila Vélez Arango',        'camila.velez@pascualbravo.edu.co',       '$2b$12$K9xP09CamilaHashSeg', 'Ingeniería de Software',               3, FALSE, '2026-05-14 08:50:00-05', 'ACTIVO'),
('Sebastián Cano Giraldo',     'sebastian.cano@pascualbravo.edu.co',     '$2b$12$K9xP10SebasHashSeg',  'Tecnología en Desarrollo de Software', 2, FALSE, '2026-09-01 17:05:00-05', 'INACTIVO');

-- 1.2 Inserción de Perfiles Extendidos con Habilidades y Deportes en JSONB (Tabla: perfiles)
INSERT INTO perfiles (id_usuario, biografia, avatar_url, habilidades_intereses_json, ultima_actualizacion) VALUES
(1, 'Desarrollador backend y arquitecto de bases de datos. Mentor en SQL, C#, estructuras en C++ y Angular.', 'https://cdn.pascualina.edu.co/avatars/u1.png',
 '{"disciplinas_academicas": ["Bases de Datos", "POO en C#", "Estructuras de Datos en C++", "Álgebra Lineal"], "lenguajes_tecnologias": ["SQL", "PostgreSQL", "C#", "C++", "Angular", "Python"], "deportes_hobbies": ["Polo Acuático", "Ajedrez", "Slay the Spire"], "disponibilidad_mentoria": ["Lunes 16:00-18:00", "Jueves 14:00-16:00"]}'::jsonb, '2026-11-10 10:00:00-05'),
(2, 'Desarrollador web fullstack con enfoque en Angular, RxJS y algoritmos competitivos.', 'https://cdn.pascualina.edu.co/avatars/u2.png',
 '{"disciplinas_academicas": ["Desarrollo Web", "Álgebra Lineal", "Inglés Conversacional"], "lenguajes_tecnologias": ["TypeScript", "Angular", "Node.js", "SQL"], "deportes_hobbies": ["Fútbol", "Programación Competitiva"], "disponibilidad_mentoria": ["Martes 15:00-17:00"]}'::jsonb, '2026-11-10 11:00:00-05'),
(3, 'Estudiante de segundo semestre interesada en bases de datos relacionales y desarrollo en Python.', 'https://cdn.pascualina.edu.co/avatars/u3.png',
 '{"disciplinas_academicas": ["Bases de Datos 1", "Lógica de Programación"], "lenguajes_tecnologias": ["Python", "SQL"], "deportes_hobbies": ["Voleibol", "Fotografía"]}'::jsonb, '2026-11-11 09:30:00-05'),
(4, 'Investigador en redes eléctricas inteligentes, telemetría IoT y automatización.', 'https://cdn.pascualina.edu.co/avatars/u4.png',
 '{"disciplinas_academicas": ["Sistemas de Potencia", "IoT Industrial", "Cálculo Vectorial"], "lenguajes_tecnologias": ["C++", "Python", "MATLAB"], "deportes_hobbies": ["Ciclismo", "Robótica"], "disponibilidad_mentoria": ["Miércoles 10:00-12:00"]}'::jsonb, '2026-11-11 14:00:00-05'),
(5, 'Iniciando en el mundo del desarrollo de software. Busco grupo de estudio para POO y bases de datos.', 'https://cdn.pascualina.edu.co/avatars/u5.png',
 '{"disciplinas_academicas": ["Matemáticas Discretas", "Introducción a la Programación"], "lenguajes_tecnologias": ["C#", "HTML", "CSS"], "deportes_hobbies": ["Natación", "Minecraft"]}'::jsonb, '2026-11-12 08:15:00-05'),
(6, 'Entusiasta de la programación competitiva, arquitectura cloud y seguridad informática.', 'https://cdn.pascualina.edu.co/avatars/u6.png',
 '{"disciplinas_academicas": ["Estructuras de Datos", "Arquitectura de Software", "Seguridad"], "lenguajes_tecnologias": ["C++", "Rust", "Go", "PostgreSQL"], "deportes_hobbies": ["Atletismo", "Ajedrez"], "disponibilidad_mentoria": ["Viernes 14:00-17:00"]}'::jsonb, '2026-11-12 16:40:00-05'),
(7, 'Diseñadora UX/UI apasionada por crear interfaces accesibles para proyectos estudiantiles.', 'https://cdn.pascualina.edu.co/avatars/u7.png',
 '{"disciplinas_academicas": ["Diseño de Interfaces", "Prototipado Ágil"], "lenguajes_tecnologias": ["Figma", "HTML", "CSS", "Bootstrap"], "deportes_hobbies": ["Ilustración Digital", "Tenis de Mesa"]}'::jsonb, '2026-11-12 18:00:00-05'),
(8, 'Integrador de hardware y firmware para sensores ambientales en campus inteligentes.', 'https://cdn.pascualina.edu.co/avatars/u8.png',
 '{"disciplinas_academicas": ["Microcontroladores", "Sensórica IoT", "Control Automático"], "lenguajes_tecnologias": ["C", "C++", "MicroPython", "MQTT"], "deportes_hobbies": ["Fútbol Sala", "Impresión 3D"], "disponibilidad_mentoria": ["Jueves 10:00-12:00"]}'::jsonb, '2026-11-13 09:10:00-05'),
(9, 'Estudiante de Ingeniería de Software enfocada en analítica de datos y muestreo estadístico.', 'https://cdn.pascualina.edu.co/avatars/u9.png',
 '{"disciplinas_academicas": ["Estadística y Probabilidad", "Bases de Datos 1", "Ingeniería de Requisitos"], "lenguajes_tecnologias": ["SQL", "Python", "R"], "deportes_hobbies": ["Baloncesto", "Cine"]}'::jsonb, '2026-11-13 11:25:00-05'),
(10, 'Estudiante de desarrollo interesado en videojuegos móviles y motores gráficos.', 'https://cdn.pascualina.edu.co/avatars/u10.png',
 '{"disciplinas_academicas": ["Programación Orientada a Objetos"], "lenguajes_tecnologias": ["C#", "Unity"], "deportes_hobbies": ["Call of Duty Mobile", "Fútbol"]}'::jsonb, '2026-11-13 15:00:00-05');

-- 1.3 Inserción de Conexiones entre Compañeros y Relaciones de Mentoría (Tabla: conexiones)
INSERT INTO conexiones (id_seguidor, id_seguido, tipo_vinculo, estado_vinculo, fecha_conexion) VALUES
(3, 1, 'MENTORIA', 'ACEPTADO',  '2026-09-05 10:00:00-05'),
(5, 1, 'MENTORIA', 'ACEPTADO',  '2026-09-10 14:30:00-05'),
(9, 1, 'MENTORIA', 'ACEPTADO',  '2026-09-15 16:00:00-05'),
(10, 1, 'MENTORIA', 'PENDIENTE', '2026-11-01 09:00:00-05'),
(2, 1, 'PAR',      'ACEPTADO',  '2026-03-01 08:00:00-05'),
(1, 2, 'PAR',      'ACEPTADO',  '2026-03-01 08:05:00-05'),
(6, 1, 'PAR',      'ACEPTADO',  '2026-04-12 11:20:00-05'),
(3, 2, 'MENTORIA', 'ACEPTADO',  '2026-09-18 15:10:00-05'),
(5, 2, 'MENTORIA', 'PENDIENTE', '2026-11-05 13:40:00-05'),
(7, 2, 'PAR',      'ACEPTADO',  '2026-06-20 17:00:00-05'),
(8, 4, 'MENTORIA', 'ACEPTADO',  '2026-05-10 10:30:00-05'),
(1, 6, 'PAR',      'ACEPTADO',  '2026-04-15 12:00:00-05'),
(9, 6, 'MENTORIA', 'ACEPTADO',  '2026-10-01 09:45:00-05'),
(3, 6, 'MENTORIA', 'ACEPTADO',  '2026-10-08 11:15:00-05'),
(5, 8, 'PAR',      'BLOQUEADO', '2026-10-20 19:00:00-05');

-- 1.4 Inserción de Actualizaciones en el Muro (Tabla: publicaciones)
INSERT INTO publicaciones (id_autor, categoria_post, contenido_texto, recurso_multimedia_url, fecha_publicacion) VALUES
(1, 'RECURSO_UTIL',   'Comparto guía práctica sobre normalización en 3FN, vistas SQL y uso de índices GIN sobre JSONB en PostgreSQL 15.', 'https://github.com/Al3zxs/RedUniConnect/docs/guia_vistas_sql.pdf', '2026-11-01 09:30:00-05'),
(3, 'PREGUNTA_TAREA', '¿Alguien me puede explicar la diferencia práctica entre usar WHERE y HAVING al agrupar conteos de miembros por grupo?', NULL, '2026-11-02 14:15:00-05'),
(2, 'RECURSO_UTIL',   'Plantilla de proyecto Angular con arquitectura NgModule, servicios reactivos RxJS y formularios validados con Bootstrap.', 'https://github.com/Al3zxs/AgroComercial', '2026-11-03 11:00:00-05'),
(6, 'NOTICIA_TECH',   'PostgreSQL incorpora mejoras de rendimiento en consultas analíticas y operadores JSONB para cargas mixtas OLTP/OLAP.', 'https://www.postgresql.org/docs/current/datatype-json.html', '2026-11-04 16:45:00-05'),
(5, 'PREGUNTA_TAREA', 'Estoy implementando pilas (LIFO) y colas (FIFO) con memoria dinámica en C++. ¿Cómo evito fugas de memoria al desencolar?', NULL, '2026-11-05 18:20:00-05'),
(1, 'RECURSO_UTIL',   'Repositorio de ejemplo con implementación de listas enlazadas, pilas y colas en C++ para gestión académica.', 'https://github.com/Al3zxs/estructuras-cpp-pascual', '2026-11-06 08:10:00-05'),
(7, 'MEME',           'Cuando ejecutas un UPDATE sin cláusula WHERE en producción... menos mal estamos en una transacción con BEGIN y ROLLBACK.', 'https://cdn.pascualina.edu.co/memes/update_sin_where.png', '2026-11-07 20:05:00-05'),
(4, 'NOTICIA_TECH',   'Nuevos nodos sensores de CO2 y lectores RFID instalados en el Bloque B para monitoreo de eventos del Smart Campus.', 'https://cdn.pascualina.edu.co/noticias/iot_campus_2026.pdf', '2026-11-08 10:30:00-05'),
(9, 'PREGUNTA_TAREA', '¿Qué estrategia recomiendan para calcular el tamaño de muestra en muestreo aleatorio estratificado por facultad?', NULL, '2026-11-09 13:50:00-05'),
(8, 'RECURSO_UTIL',   'Script en Python para lectura de telemetría MQTT y almacenamiento en estructura JSON para PostgreSQL.', 'https://cdn.pascualina.edu.co/recursos/mqtt_to_jsonb.py', '2026-11-10 15:40:00-05'),
(2, 'MEME',           'Mi cara cuando la consulta con 4 INNER JOIN y 2 LEFT JOIN corre en 3 milisegundos al primer intento en pgAdmin 4.', 'https://cdn.pascualina.edu.co/memes/joins_primera.jpg', '2026-11-11 19:15:00-05'),
(1, 'NOTICIA_TECH',   'Abiertas las inscripciones para la Hackatón Smart Campus Pascualina 2026. ¡Armen sus equipos interdisciplinarios!', 'https://cdn.pascualina.edu.co/eventos/hackaton2026', '2026-11-12 09:00:00-05');

-- 1.5 Inserción de Grupos de Estudio, Equipos de Hackatón y Clubes (Tabla: grupos)
INSERT INTO grupos (id_creador, nombre_grupo, descripcion, tipo_grupo, es_privado, fecha_creacion) VALUES
(1, 'Semillero de Bases de Datos y SQL Avanzado', 'Grupo de estudio enfocado en modelado relacional, DML avanzado, vistas analíticas y optimización en PostgreSQL.', 'ESTUDIO_MATERIA', FALSE, '2026-08-15 10:00:00-05'),
(1, 'Club de Hackatones e IoT Pascualino',        'Equipo competitivo para desarrollar soluciones de software e integración con sensores del Smart Campus.', 'EQUIPO_HACKATON', FALSE, '2026-08-20 14:00:00-05'),
(6, 'Club de Programación Competitiva y C++',     'Entrenamiento semanal en estructuras de datos, grafos, programación dinámica y maratones ICPC.', 'CLUB_INTERES',    FALSE, '2026-09-01 16:00:00-05'),
(2, 'Comunidad Desarrollo Web Angular & C#',      'Espacio práctico para construir aplicaciones empresariales con Angular (NgModule) y APIs en .NET / C#.', 'ESTUDIO_MATERIA', FALSE, '2026-09-10 11:30:00-05'),
(7, 'Laboratorio UX/UI y Producto Digital',       'Equipo cerrado para diseño de prototipos de alta fidelidad de los proyectos de hackatón.', 'EQUIPO_HACKATON', TRUE,  '2026-09-25 15:00:00-05');

-- 1.6 Inserción de Miembros en Grupos (Tabla: miembros_grupo)
INSERT INTO miembros_grupo (id_grupo, id_usuario, rol_en_grupo, fecha_ingreso) VALUES
-- Grupo 1: Semillero de Bases de Datos y SQL Avanzado
(1, 1, 'ADMIN',     '2026-08-15 10:00:00-05'),
(1, 2, 'MODERADOR', '2026-08-16 11:00:00-05'),
(1, 3, 'MIEMBRO',   '2026-08-18 09:20:00-05'),
(1, 5, 'MIEMBRO',   '2026-08-22 14:10:00-05'),
(1, 9, 'MIEMBRO',   '2026-08-25 16:30:00-05'),
-- Grupo 2: Club de Hackatones e IoT Pascualino
(2, 1, 'ADMIN',     '2026-08-20 14:00:00-05'),
(2, 4, 'MODERADOR', '2026-08-21 10:00:00-05'),
(2, 8, 'MODERADOR', '2026-08-21 10:15:00-05'),
(2, 2, 'MIEMBRO',   '2026-08-23 12:00:00-05'),
(2, 6, 'MIEMBRO',   '2026-08-24 15:45:00-05'),
(2, 7, 'MIEMBRO',   '2026-08-26 17:00:00-05'),
-- Grupo 3: Club de Programación Competitiva y C++
(3, 6, 'ADMIN',     '2026-09-01 16:00:00-05'),
(3, 1, 'MODERADOR', '2026-09-02 09:00:00-05'),
(3, 2, 'MIEMBRO',   '2026-09-03 11:00:00-05'),
(3, 5, 'MIEMBRO',   '2026-09-05 14:30:00-05'),
-- Grupo 4: Comunidad Desarrollo Web Angular & C#
(4, 2, 'ADMIN',     '2026-09-10 11:30:00-05'),
(4, 1, 'MODERADOR', '2026-09-10 12:00:00-05'),
(4, 3, 'MIEMBRO',   '2026-09-12 10:20:00-05'),
(4, 7, 'MIEMBRO',   '2026-09-14 16:10:00-05'),
(4, 9, 'MIEMBRO',   '2026-09-15 08:40:00-05'),
-- Grupo 5: Laboratorio UX/UI y Producto Digital
(5, 7, 'ADMIN',     '2026-09-25 15:00:00-05'),
(5, 2, 'MIEMBRO',   '2026-09-26 10:00:00-05'),
(5, 9, 'MIEMBRO',   '2026-09-27 11:30:00-05');

-- 1.7 Inserción de Eventos Académicos y Sociales con Telemetría IoT (Tabla: eventos)
INSERT INTO eventos (
    id_grupo, id_organizador, titulo_evento, descripcion_evento,
    modalidad_evento, ubicacion_aula, fecha_hora_inicio, fecha_hora_fin, telemetria_iot_json
) VALUES
(1, 1, 'Taller Práctico de Consultas DML y Vistas en PostgreSQL',
 'Sesión intensiva para dominar JOINs, funciones de agregación, alias estandarizados y vistas analíticas en pgAdmin 4.',
 'TALLER', 'Laboratorio de Software Bloque 14 - Sala 302',
 '2026-11-14 14:00:00-05', '2026-11-14 17:00:00-05',
 '{
    "sensor_nodo_id": "IOT-LAB-B14-S302",
    "ultima_sincronizacion": "2026-11-14T16:45:00-05:00",
    "control_aforo": {"capacidad_maxima": 40, "ocupacion_actual": 36, "accesos_rfid_validados": 36, "alerta_sobrecupo": false},
    "metricas_ambientales": {"temperatura_celsius": 21.8, "humedad_relativa_pct": 54, "co2_ppm": 580, "calidad_aire": "OPTIMA"},
    "telemetria_red_hackaton": {"dispositivos_conectados_wifi": 42, "consumo_energetico_kwh": 18.5}
 }'::jsonb),

(2, 1, 'Hackatón Smart Campus Pascualina 2026',
 'Maratón de 12 horas desarrollando soluciones con datos de sensores universitarios y bases de datos híbridas.',
 'HACKATON', 'Auditorio Bloque B - Aula 204',
 '2026-11-15 08:00:00-05', '2026-11-15 20:00:00-05',
 '{
    "sensor_nodo_id": "IOT-AUDITORIO-B204",
    "ultima_sincronizacion": "2026-11-15T13:00:00-05:00",
    "control_aforo": {"capacidad_maxima": 120, "ocupacion_actual": 98, "accesos_rfid_validados": 95, "alerta_sobrecupo": false},
    "metricas_ambientales": {"temperatura_celsius": 22.4, "humedad_relativa_pct": 58, "co2_ppm": 610, "calidad_aire": "OPTIMA"},
    "telemetria_red_hackaton": {"dispositivos_conectados_wifi": 184, "consumo_energetico_kwh": 45.8}
 }'::jsonb),

(3, 6, 'Maratón de Entrenamiento en Estructuras de Datos C++',
 'Resolución colaborativa de problemas sobre árboles, pilas, colas y grafos previo al torneo interuniversitario.',
 'REUNION_ESTUDIO', 'Aula Taller Bloque 8 - Salón 105',
 '2026-11-18 15:00:00-05', '2026-11-18 18:00:00-05',
 '{
    "sensor_nodo_id": "IOT-AULA-B8-105",
    "ultima_sincronizacion": "2026-11-15T12:00:00-05:00",
    "control_aforo": {"capacidad_maxima": 35, "ocupacion_actual": 28, "accesos_rfid_validados": 27, "alerta_sobrecupo": false},
    "metricas_ambientales": {"temperatura_celsius": 23.1, "humedad_relativa_pct": 60, "co2_ppm": 640, "calidad_aire": "BUENA"},
    "telemetria_red_hackaton": {"dispositivos_conectados_wifi": 31, "consumo_energetico_kwh": 12.2}
 }'::jsonb),

(4, 2, 'Sesión de Estudio: Arquitectura Angular y Servicios RxJS',
 'Revisión práctica de componentes, módulos, formularios reactivos e integración con backend.',
 'REUNION_ESTUDIO', 'Sala Virtual Microsoft Teams - Canal Ingeniería',
 '2026-11-20 18:00:00-05', '2026-11-20 20:00:00-05',
 NULL),

(NULL, 4, 'Encuentro Social y Torneo Relámpago de Ajedrez y E-Sports',
 'Actividad de integración abierta para toda la comunidad estudiantil pascualina al cierre del semestre.',
 'ACTIVIDAD_SOCIAL', 'Plazoleta Central Campus Robledo',
 '2026-11-25 13:00:00-05', '2026-11-25 17:00:00-05',
 '{
    "sensor_nodo_id": "IOT-PLAZOLETA-CENTRAL",
    "ultima_sincronizacion": "2026-11-15T12:30:00-05:00",
    "control_aforo": {"capacidad_maxima": 200, "ocupacion_actual": 145, "accesos_rfid_validados": 140, "alerta_sobrecupo": false},
    "metricas_ambientales": {"temperatura_celsius": 24.5, "humedad_relativa_pct": 52, "co2_ppm": 430, "calidad_aire": "EXCELENTE"},
    "telemetria_red_hackaton": {"dispositivos_conectados_wifi": 210, "consumo_energetico_kwh": 22.0}
 }'::jsonb);

-- 1.8 Inserción de Asistentes a Eventos (Tabla: asistentes_evento)
INSERT INTO asistentes_evento (id_evento, id_usuario, estado_participacion, fecha_inscripcion) VALUES
-- Evento 1: Taller DML y Vistas
(1, 1, 'ASISTIO',    '2026-11-01 10:00:00-05'),
(1, 2, 'ASISTIO',    '2026-11-01 11:00:00-05'),
(1, 3, 'ASISTIO',    '2026-11-02 09:30:00-05'),
(1, 5, 'ASISTIO',    '2026-11-03 14:00:00-05'),
(1, 9, 'ASISTIO',    '2026-11-04 16:00:00-05'),
(1, 7, 'CONFIRMADO', '2026-11-05 12:00:00-05'),
-- Evento 2: Hackatón Smart Campus
(2, 1, 'ASISTIO',    '2026-11-01 08:00:00-05'),
(2, 2, 'ASISTIO',    '2026-11-01 08:30:00-05'),
(2, 4, 'ASISTIO',    '2026-11-01 09:00:00-05'),
(2, 6, 'ASISTIO',    '2026-11-02 10:15:00-05'),
(2, 7, 'ASISTIO',    '2026-11-02 11:45:00-05'),
(2, 8, 'ASISTIO',    '2026-11-03 15:20:00-05'),
(2, 3, 'CONFIRMADO', '2026-11-05 17:10:00-05'),
(2, 9, 'CONFIRMADO', '2026-11-06 13:00:00-05'),
(2, 5, 'INTERESADO', '2026-11-08 18:00:00-05'),
-- Evento 3: Maratón Estructuras C++
(3, 6, 'CONFIRMADO', '2026-11-08 10:00:00-05'),
(3, 1, 'CONFIRMADO', '2026-11-08 10:30:00-05'),
(3, 2, 'CONFIRMADO', '2026-11-09 11:00:00-05'),
(3, 5, 'CONFIRMADO', '2026-11-10 14:20:00-05'),
(3, 3, 'INTERESADO', '2026-11-11 09:00:00-05'),
-- Evento 4: Sesión Estudio Angular
(4, 2, 'CONFIRMADO', '2026-11-10 08:00:00-05'),
(4, 1, 'CONFIRMADO', '2026-11-10 08:15:00-05'),
(4, 3, 'CONFIRMADO', '2026-11-11 10:00:00-05'),
(4, 7, 'CONFIRMADO', '2026-11-12 16:00:00-05'),
(4, 9, 'INTERESADO', '2026-11-13 12:00:00-05'),
-- Evento 5: Encuentro Social Ajedrez y E-Sports
(5, 4, 'CONFIRMADO', '2026-11-10 14:00:00-05'),
(5, 1, 'CONFIRMADO', '2026-11-10 15:00:00-05'),
(5, 2, 'CONFIRMADO', '2026-11-11 16:30:00-05'),
(5, 6, 'CONFIRMADO', '2026-11-12 09:45:00-05'),
(5, 8, 'CONFIRMADO', '2026-11-12 11:10:00-05'),
(5, 10, 'CANCELADO', '2026-11-13 17:00:00-05');

-- =============================================================================
-- 2. OPERACIONES DML DE ACTUALIZACIÓN Y DEPURACIÓN (UPDATE Y DELETE)
-- Demuestran el mantenimiento transaccional seguro del modelo de negocio.
-- =============================================================================

-- 2.1 UPDATE: Aprobar solicitudes de mentoría pendientes dirigidas a mentores activos
UPDATE conexiones c
SET
    estado_vinculo = 'ACEPTADO',
    fecha_conexion = CURRENT_TIMESTAMP
FROM usuarios u
WHERE c.id_seguido = u.id_usuario
  AND c.tipo_vinculo = 'MENTORIA'
  AND c.estado_vinculo = 'PENDIENTE'
  AND u.es_mentor = TRUE
  AND u.estado_cuenta = 'ACTIVO';

-- 2.2 UPDATE: Habilitar como mentora a la estudiante de 4° semestre de Diseño Gráfico
-- y enriquecer su perfil JSONB con horario de mentoría en UX/UI
UPDATE usuarios
SET es_mentor = TRUE
WHERE correo_institucional = 'sofia.patino@pascualbravo.edu.co';

UPDATE perfiles
SET
    habilidades_intereses_json = jsonb_set(
        habilidades_intereses_json,
        '{disponibilidad_mentoria}',
        '["Miércoles 14:00-16:00"]'::jsonb,
        TRUE
    ),
    ultima_actualizacion = CURRENT_TIMESTAMP
WHERE id_usuario = (
    SELECT id_usuario FROM usuarios WHERE correo_institucional = 'sofia.patino@pascualbravo.edu.co'
);

-- 2.3 DELETE: Depurar vínculos bloqueados para mantener limpia la matriz activa de red
DELETE FROM conexiones
WHERE estado_vinculo = 'BLOQUEADO';

-- 2.4 DELETE: Retirar inscripciones en estado 'CANCELADO' de eventos futuros
DELETE FROM asistentes_evento
WHERE estado_participacion = 'CANCELADO';

-- =============================================================================
-- 3. SISTEMA DE VISTAS ANALÍTICAS (CREATE OR REPLACE VIEW)
-- Cada vista encapsula lógica relacional y semiestructurada (JSONB) aplicando
-- estrictamente la nomenclatura snake_case en los ALIAS de datos calculados.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- VISTA 1: vw_directorio_mentores_habilidades
-- Propósito Analítico: Consolida los perfiles estudiantiles, extrae conteos de
-- habilidades técnicas/académicas/deportivas desde JSONB y calcula indicadores
-- de impacto en mentoría y redes de apoyo entre compañeros.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_directorio_mentores_habilidades AS
SELECT
    u.id_usuario AS codigo_estudiante,
    u.nombre_completo AS nombre_estudiante,
    u.correo_institucional AS correo_educativo,
    u.programa_academico AS nombre_programa,
    u.semestre_actual AS numero_semestre,
    CASE
        WHEN u.semestre_actual >= 7 THEN 'Avanzado Superior (7° a 12°)'
        WHEN u.semestre_actual BETWEEN 4 AND 6 THEN 'Ciclo Intermedio (4° a 6°)'
        ELSE 'Ciclo Inicial (1° a 3°)'
    END AS clasificacion_ciclo_academico,
    u.es_mentor AS indicador_mentor_activo,
    COALESCE(jsonb_array_length(p.habilidades_intereses_json->'disciplinas_academicas'), 0) AS total_disciplinas_academicas,
    COALESCE(jsonb_array_length(p.habilidades_intereses_json->'lenguajes_tecnologias'), 0) AS total_habilidades_tecnologicas,
    COALESCE(jsonb_array_length(p.habilidades_intereses_json->'deportes_hobbies'), 0) AS total_deportes_intereses,
    (
        COALESCE(jsonb_array_length(p.habilidades_intereses_json->'disciplinas_academicas'), 0) +
        COALESCE(jsonb_array_length(p.habilidades_intereses_json->'lenguajes_tecnologias'), 0) +
        COALESCE(jsonb_array_length(p.habilidades_intereses_json->'deportes_hobbies'), 0)
    ) AS total_competencias_perfil,
    COUNT(DISTINCT c_seg.id_conexion) FILTER (WHERE c_seg.tipo_vinculo = 'MENTORIA' AND c_seg.estado_vinculo = 'ACEPTADO') AS total_mentorizados_activos,
    COUNT(DISTINCT c_seg.id_conexion) FILTER (WHERE c_seg.tipo_vinculo = 'PAR' AND c_seg.estado_vinculo = 'ACEPTADO') AS total_seguidores_pares,
    COUNT(DISTINCT c_seg.id_conexion) FILTER (WHERE c_seg.estado_vinculo = 'ACEPTADO') AS total_red_apoyo_recibida,
    EXTRACT(DAY FROM (CURRENT_TIMESTAMP - u.fecha_registro))::INT AS dias_antiguedad_plataforma
FROM usuarios u
INNER JOIN perfiles p ON u.id_usuario = p.id_usuario
LEFT JOIN conexiones c_seg ON u.id_usuario = c_seg.id_seguido
WHERE u.estado_cuenta = 'ACTIVO'
GROUP BY
    u.id_usuario, u.nombre_completo, u.correo_institucional,
    u.programa_academico, u.semestre_actual, u.es_mentor,
    u.fecha_registro, p.habilidades_intereses_json;

-- -----------------------------------------------------------------------------
-- VISTA 2: vw_analitica_muro_publicaciones
-- Propósito Analítico: Evalúa el comportamiento de publicación en el muro
-- universitario desglosando preguntas de tarea, recursos útiles, noticias tech
-- y memes, y calculando el porcentaje de aporte académico por autor.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_analitica_muro_publicaciones AS
SELECT
    u.id_usuario AS codigo_autor,
    u.nombre_completo AS nombre_autor,
    u.programa_academico AS programa_autor,
    u.semestre_actual AS semestre_autor,
    COUNT(pub.id_publicacion) AS total_publicaciones_autor,
    COUNT(pub.id_publicacion) FILTER (WHERE pub.categoria_post = 'PREGUNTA_TAREA') AS total_preguntas_tarea,
    COUNT(pub.id_publicacion) FILTER (WHERE pub.categoria_post = 'RECURSO_UTIL') AS total_recursos_utiles,
    COUNT(pub.id_publicacion) FILTER (WHERE pub.categoria_post = 'NOTICIA_TECH') AS total_noticias_tecnologicas,
    COUNT(pub.id_publicacion) FILTER (WHERE pub.categoria_post = 'MEME') AS total_memes_universitarios,
    COUNT(pub.recurso_multimedia_url) AS total_posts_con_multimedia,
    ROUND(
        (
            COUNT(pub.id_publicacion) FILTER (
                WHERE pub.categoria_post IN ('PREGUNTA_TAREA', 'RECURSO_UTIL', 'NOTICIA_TECH')
            )::NUMERIC * 100.0
        ) / NULLIF(COUNT(pub.id_publicacion), 0),
        2
    ) AS porcentaje_aporte_academico_pct,
    MAX(pub.fecha_publicacion) AS fecha_ultima_publicacion
FROM usuarios u
LEFT JOIN publicaciones pub ON u.id_usuario = pub.id_autor
WHERE u.estado_cuenta = 'ACTIVO'
GROUP BY u.id_usuario, u.nombre_completo, u.programa_academico, u.semestre_actual;

-- -----------------------------------------------------------------------------
-- VISTA 3: vw_ecosistema_grupos_comunidades
-- Propósito Analítico: Mide la salud, interdisciplinariedad y liderazgo de los
-- grupos de estudio, equipos de hackatón y clubes de interés.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_ecosistema_grupos_comunidades AS
SELECT
    g.id_grupo AS codigo_grupo,
    g.nombre_grupo AS nombre_comunidad,
    g.tipo_grupo AS categoria_comunidad,
    CASE
        WHEN g.es_privado = TRUE THEN 'Privado (Con Aprobación)'
        ELSE 'Público (Abierto)'
    END AS modalidad_acceso_grupo,
    u_cre.nombre_completo AS nombre_estudiante_fundador,
    COUNT(DISTINCT mg.id_usuario) AS total_miembros_activos,
    COUNT(DISTINCT mg.id_usuario) FILTER (WHERE mg.rol_en_grupo IN ('ADMIN', 'MODERADOR')) AS total_lideres_moderadores,
    COUNT(DISTINCT u_miem.programa_academico) AS total_programas_representados,
    ROUND(AVG(u_miem.semestre_actual)::NUMERIC, 2) AS promedio_semestre_integrantes,
    COUNT(DISTINCT ev.id_evento) AS total_eventos_organizados
FROM grupos g
INNER JOIN usuarios u_cre ON g.id_creador = u_cre.id_usuario
LEFT JOIN miembros_grupo mg ON g.id_grupo = mg.id_grupo
LEFT JOIN usuarios u_miem ON mg.id_usuario = u_miem.id_usuario
LEFT JOIN eventos ev ON g.id_grupo = ev.id_grupo
GROUP BY
    g.id_grupo, g.nombre_grupo, g.tipo_grupo,
    g.es_privado, u_cre.nombre_completo;

-- -----------------------------------------------------------------------------
-- VISTA 4: vw_monitoreo_eventos_smart_campus
-- Propósito Analítico: Combina los registros relacionales de asistencia a
-- eventos con las lecturas NoSQL (JSONB) de los sensores IoT de aula/auditorio
-- para auditar ocupación física, tasa de asistencia y calidad ambiental.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_monitoreo_eventos_smart_campus AS
SELECT
    e.id_evento AS codigo_evento,
    e.titulo_evento AS nombre_actividad,
    e.modalidad_evento AS categoria_evento,
    COALESCE(g.nombre_grupo, 'Evento Institucional Abierto') AS comunidad_organizadora,
    u_org.nombre_completo AS nombre_coordinador,
    e.ubicacion_aula AS espacio_fisico_o_virtual,
    e.fecha_hora_inicio AS instante_apertura,
    e.fecha_hora_fin AS instante_cierre,
    ROUND(
        EXTRACT(EPOCH FROM (e.fecha_hora_fin - e.fecha_hora_inicio))::NUMERIC / 3600.0,
        2
    ) AS duracion_programada_horas,
    COUNT(DISTINCT ae.id_usuario) AS total_inscritos_sistema,
    COUNT(DISTINCT ae.id_usuario) FILTER (WHERE ae.estado_participacion IN ('CONFIRMADO', 'ASISTIO')) AS total_confirmados_o_asistentes,
    COUNT(DISTINCT ae.id_usuario) FILTER (WHERE ae.estado_participacion = 'ASISTIO') AS total_asistentes_validados,
    COALESCE((e.telemetria_iot_json->'control_aforo'->>'capacidad_maxima')::INT, 0) AS capacidad_maxima_iot,
    COALESCE((e.telemetria_iot_json->'control_aforo'->>'ocupacion_actual')::INT, 0) AS ocupacion_sensor_iot,
    ROUND(
        (
            COALESCE((e.telemetria_iot_json->'control_aforo'->>'ocupacion_actual')::NUMERIC, 0) * 100.0
        ) / NULLIF((e.telemetria_iot_json->'control_aforo'->>'capacidad_maxima')::NUMERIC, 0),
        2
    ) AS porcentaje_ocupacion_aforo_pct,
    COALESCE((e.telemetria_iot_json->'metricas_ambientales'->>'temperatura_celsius')::NUMERIC, 0.0) AS temperatura_aula_celsius,
    COALESCE((e.telemetria_iot_json->'metricas_ambientales'->>'co2_ppm')::INT, 0) AS concentracion_co2_ppm,
    COALESCE(e.telemetria_iot_json->'metricas_ambientales'->>'calidad_aire', 'SIN_SENSOR_VIRTUAL') AS estado_calidad_aire_iot
FROM eventos e
INNER JOIN usuarios u_org ON e.id_organizador = u_org.id_usuario
LEFT JOIN grupos g ON e.id_grupo = g.id_grupo
LEFT JOIN asistentes_evento ae ON e.id_evento = ae.id_evento
GROUP BY
    e.id_evento, e.titulo_evento, e.modalidad_evento,
    g.nombre_grupo, u_org.nombre_completo, e.ubicacion_aula,
    e.fecha_hora_inicio, e.fecha_hora_fin, e.telemetria_iot_json;

-- -----------------------------------------------------------------------------
-- VISTA 5: vw_kpi_resumen_programa_academico
-- Propósito Analítico: Tablero de control gerencial por carrera que sintetiza
-- adopción estudiantil, oferta de mentores, producción de contenido y
-- participación comunitaria.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW vw_kpi_resumen_programa_academico AS
SELECT
    u.programa_academico AS nombre_programa_academico,
    COUNT(DISTINCT u.id_usuario) AS total_estudiantes_registrados,
    COUNT(DISTINCT u.id_usuario) FILTER (WHERE u.estado_cuenta = 'ACTIVO') AS total_estudiantes_activos,
    COUNT(DISTINCT u.id_usuario) FILTER (WHERE u.es_mentor = TRUE AND u.estado_cuenta = 'ACTIVO') AS total_mentores_disponibles,
    ROUND(AVG(u.semestre_actual)::NUMERIC, 2) AS promedio_semestre_programa,
    COUNT(DISTINCT pub.id_publicacion) AS total_publicaciones_generadas,
    COUNT(DISTINCT mg.id_grupo) AS total_grupos_con_participacion,
    COUNT(DISTINCT ae.id_evento) AS total_eventos_con_asistencia,
    ROUND(
        (
            COUNT(DISTINCT u.id_usuario) FILTER (WHERE u.es_mentor = TRUE AND u.estado_cuenta = 'ACTIVO')::NUMERIC * 100.0
        ) / NULLIF(COUNT(DISTINCT u.id_usuario) FILTER (WHERE u.estado_cuenta = 'ACTIVO'), 0),
        2
    ) AS tasa_cobertura_mentoria_pct
FROM usuarios u
LEFT JOIN publicaciones pub ON u.id_usuario = pub.id_autor
LEFT JOIN miembros_grupo mg ON u.id_usuario = mg.id_usuario
LEFT JOIN asistentes_evento ae ON u.id_usuario = ae.id_usuario
GROUP BY u.programa_academico;

-- =============================================================================
-- 4. SISTEMA DE CONSULTAS DE NEGOCIO Y EXPLOTACIÓN DE VISTAS (DML - SELECT)
-- Responden directamente a las preguntas estratégicas de la Red Social Pascualina.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- CONSULTA 1 (Requisito: Perfiles, intereses y habilidades tecnológicas/deportivas)
-- Pregunta de Negocio: ¿Qué estudiantes activos poseen habilidades en 'SQL' o 'C++',
-- cuáles son sus deportes/intereses registrados y cuántas competencias suman?
-- -----------------------------------------------------------------------------
SELECT
    v.codigo_estudiante,
    v.nombre_estudiante,
    v.nombre_programa,
    v.numero_semestre,
    v.clasificacion_ciclo_academico,
    p.habilidades_intereses_json->'lenguajes_tecnologias' AS listado_tecnologias_json,
    p.habilidades_intereses_json->'deportes_hobbies' AS listado_deportes_hobbies_json,
    v.total_competencias_perfil,
    v.dias_antiguedad_plataforma
FROM vw_directorio_mentores_habilidades v
INNER JOIN perfiles p ON v.codigo_estudiante = p.id_usuario
WHERE p.habilidades_intereses_json->'lenguajes_tecnologias' ?| array['SQL', 'C++']
ORDER BY v.total_competencias_perfil DESC, v.numero_semestre DESC;

-- -----------------------------------------------------------------------------
-- CONSULTA 2 (Requisito: Conectar con compañeros y encontrar mentores avanzados)
-- Pregunta de Negocio: ¿Cuáles son los mentores activos de cursos avanzados con
-- mayor impacto en la red de acompañamiento y quiénes son sus mentorizados?
-- -----------------------------------------------------------------------------
SELECT
    vm.codigo_estudiante AS id_estudiante_mentor,
    vm.nombre_estudiante AS nombre_mentor,
    vm.nombre_programa AS carrera_mentor,
    vm.numero_semestre AS semestre_mentor,
    vm.total_mentorizados_activos,
    vm.total_seguidores_pares,
    vm.total_red_apoyo_recibida,
    STRING_AGG(u_est.nombre_completo || ' (Sem. ' || u_est.semestre_actual || ')', ', ' ORDER BY u_est.semestre_actual) AS lista_estudiantes_mentorizados
FROM vw_directorio_mentores_habilidades vm
LEFT JOIN conexiones c ON vm.codigo_estudiante = c.id_seguido
    AND c.tipo_vinculo = 'MENTORIA'
    AND c.estado_vinculo = 'ACEPTADO'
LEFT JOIN usuarios u_est ON c.id_seguidor = u_est.id_usuario
WHERE vm.indicador_mentor_activo = TRUE
GROUP BY
    vm.codigo_estudiante, vm.nombre_estudiante, vm.nombre_programa,
    vm.numero_semestre, vm.total_mentorizados_activos,
    vm.total_seguidores_pares, vm.total_red_apoyo_recibida
ORDER BY vm.total_mentorizados_activos DESC, vm.total_red_apoyo_recibida DESC;

-- -----------------------------------------------------------------------------
-- CONSULTA 3 (Requisito: Publicar actualizaciones - tareas, recursos, noticias, memes)
-- Pregunta de Negocio: ¿Quiénes son los estudiantes más activos en el muro y qué
-- porcentaje de sus publicaciones corresponde a contenido académico de valor?
-- -----------------------------------------------------------------------------
SELECT
    va.codigo_autor,
    va.nombre_autor,
    va.programa_autor,
    va.total_publicaciones_autor,
    va.total_preguntas_tarea,
    va.total_recursos_utiles,
    va.total_noticias_tecnologicas,
    va.total_memes_universitarios,
    va.total_posts_con_multimedia,
    va.porcentaje_aporte_academico_pct,
    CASE
        WHEN va.porcentaje_aporte_academico_pct >= 80.0 THEN 'Generador Académico Destacado'
        WHEN va.porcentaje_aporte_academico_pct >= 50.0 THEN 'Colaborador Equilibrado'
        ELSE 'Participante Social / Recreativo'
    END AS perfil_contribucion_muro
FROM vw_analitica_muro_publicaciones va
WHERE va.total_publicaciones_autor > 0
ORDER BY va.total_publicaciones_autor DESC, va.porcentaje_aporte_academico_pct DESC;

-- -----------------------------------------------------------------------------
-- CONSULTA 4 (Requisito: Crear y unirse a grupos de estudio, hackatón o clubes)
-- Pregunta de Negocio: ¿Qué grupos tienen mayor nivel de participación, diversidad
-- interdisciplinaria de carreras y actividad de eventos programados?
-- -----------------------------------------------------------------------------
SELECT
    vg.codigo_grupo,
    vg.nombre_comunidad,
    vg.categoria_comunidad,
    vg.modalidad_acceso_grupo,
    vg.nombre_estudiante_fundador,
    vg.total_miembros_activos,
    vg.total_lideres_moderadores,
    vg.total_programas_representados,
    vg.promedio_semestre_integrantes,
    vg.total_eventos_organizados,
    ROUND(
        (vg.total_lideres_moderadores::NUMERIC * 100.0) / NULLIF(vg.total_miembros_activos, 0),
        2
    ) AS proporcion_liderazgo_grupo_pct
FROM vw_ecosistema_grupos_comunidades vg
ORDER BY vg.total_miembros_activos DESC, vg.total_programas_representados DESC;

-- -----------------------------------------------------------------------------
-- CONSULTA 5 (Requisito: Programar eventos y analítica Smart Campus IoT)
-- Pregunta de Negocio: ¿Cuál es el porcentaje de ocupación real medido por sensores
-- IoT frente a la capacidad de cada recinto y cómo se relaciona con las condiciones
-- ambientales (CO2 y temperatura) y las inscripciones en plataforma?
-- -----------------------------------------------------------------------------
SELECT
    ve.codigo_evento,
    ve.nombre_actividad,
    ve.categoria_evento,
    ve.comunidad_organizadora,
    ve.espacio_fisico_o_virtual,
    ve.duracion_programada_horas,
    ve.total_inscritos_sistema,
    ve.total_confirmados_o_asistentes,
    ve.capacidad_maxima_iot,
    ve.ocupacion_sensor_iot,
    COALESCE(ve.porcentaje_ocupacion_aforo_pct, 0.00) AS porcentaje_ocupacion_aforo_pct,
    ve.temperatura_aula_celsius,
    ve.concentracion_co2_ppm,
    ve.estado_calidad_aire_iot
FROM vw_monitoreo_eventos_smart_campus ve
ORDER BY ve.instante_apertura ASC;

-- -----------------------------------------------------------------------------
-- CONSULTA 6 (Analítica Ejecutiva Global por Programa Académico)
-- Pregunta de Negocio: ¿Cómo se comparan los programas académicos de la institución
-- en adopción de la red social, cobertura de mentores y actividad colaborativa?
-- -----------------------------------------------------------------------------
SELECT
    vk.nombre_programa_academico,
    vk.total_estudiantes_registrados,
    vk.total_estudiantes_activos,
    vk.total_mentores_disponibles,
    vk.tasa_cobertura_mentoria_pct,
    vk.promedio_semestre_programa,
    vk.total_publicaciones_generadas,
    vk.total_grupos_con_participacion,
    vk.total_eventos_con_asistencia
FROM vw_kpi_resumen_programa_academico vk
ORDER BY vk.total_estudiantes_activos DESC, vk.total_publicaciones_generadas DESC;

COMMIT;
