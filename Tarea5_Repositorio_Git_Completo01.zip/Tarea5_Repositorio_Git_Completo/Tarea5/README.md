# Tarea 5 — Sistema de Consultas DML y Vistas Analíticas (RedUniConnect)

**Proyecto:** Red Social Estudiantil Pascualina (*RedUniConnect*)  
**Curso:** Bases de Datos 1 (Grupo G100 - ET0057) — Unidad 3, Actividad 1  
**Institución:** Institución Universitaria Pascual Bravo  
**Integrante:** Alejandro Valencia Jiménez  
**Motor SGBD:** PostgreSQL 15+ (pgAdmin 4)

## Arquitectura de Carpetas del Entregable (`Tarea5`)

```text
Tarea5/
├── Diccionarios/
│   ├── Diccionario_Consultas_y_Vistas_RedUniConnect.xlsx
│   ├── 01_Borrador_Inicial_DML_Vistas_RedUniConnect.sql
│   └── 02_Script_Final_DML_Vistas_RedUniConnect.sql
├── Scripts/
│   ├── 01_Borrador_Inicial_DML_Vistas_RedUniConnect.sql
│   ├── 02_Script_Final_DML_Vistas_RedUniConnect.sql
│   └── 03_Script_Alternativo_Modelo_11_Tablas_Pascualina.sql
├── Informe/
│   ├── Informe_Tecnico_DML_y_Vistas_RedUniConnect.pdf
│   └── Informe_Tecnico_DML_y_Vistas_RedUniConnect.docx
├── Video/
│   └── Guion_Sustentacion_Video_Tarea5_Alejandro_Valencia.md
└── README.md
```
