-- =============================================================================
-- PROYECTO: Red Social Estudiantil Pascualina
-- CURSO: Bases de Datos 1 (Grupo G100 - ET0057)
-- INSTITUCIÓN: Institución Universitaria Pascual Bravo
-- AUTOR: Alejandro Valencia Jiménez
-- UNIDAD 3 - TAREA 5: Script Alternativo para Modelo Relacional de 11 Tablas (Tarea 3)
-- ARCHIVO: 03_Script_Alternativo_Modelo_11_Tablas_Pascualina.sql
-- SGBD: PostgreSQL 15+ (pgAdmin 4)
-- DESCRIPCIÓN: Adaptación completa de las sentencias DML (INSERT, UPDATE, DELETE,
--              SELECT) y Vistas Analíticas (CREATE OR REPLACE VIEW) para el
--              esquema relacional puro de 11 tablas entregado en la Tarea 3
--              (programas_academicos, estudiantes, intereses_habilidades,
--              estudiante_intereses, conexiones, grupos, grupo_miembros,
--              publicaciones, comentarios, eventos, evento_asistentes).
-- =============================================================================

BEGIN;

CREATE SCHEMA IF NOT EXISTS pascualina_relacional;
SET search_path TO pascualina_relacional;

-- =============================================================================
-- 0. CREACIÓN IDEMPOTENTE DE LAS 11 TABLAS DEL MODELO FÍSICO (TAREA 3)
-- =============================================================================

CREATE TABLE IF NOT EXISTS programas_academicos (
    id_programa SERIAL,
    nombre_programa VARCHAR(120) NOT NULL,
    facultad VARCHAR(100) NOT NULL,
    CONSTRAINT pk_programas_academicos PRIMARY KEY (id_programa),
    CONSTRAINT uq_programas_nombre UNIQUE (nombre_programa)
);

CREATE TABLE IF NOT EXISTS estudiantes (
    id_estudiante SERIAL,
    id_programa INT NOT NULL,
    nombre_completo VARCHAR(120) NOT NULL,
    correo_institucional VARCHAR(150) NOT NULL,
    contrasena_hash VARCHAR(255) NOT NULL,
    semestre_actual SMALLINT NOT NULL,
    biografia TEXT,
    disponible_mentoria BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_registro TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_estudiantes PRIMARY KEY (id_estudiante),
    CONSTRAINT uq_estudiantes_correo UNIQUE (correo_institucional),
    CONSTRAINT fk_estudiantes_programa FOREIGN KEY (id_programa)
        REFERENCES programas_academicos (id_programa)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_estudiantes_semestre CHECK (semestre_actual BETWEEN 1 AND 12)
);

CREATE TABLE IF NOT EXISTS intereses_habilidades (
    id_interes SERIAL,
    nombre_interes VARCHAR(80) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    CONSTRAINT pk_intereses PRIMARY KEY (id_interes),
    CONSTRAINT uq_intereses_nombre UNIQUE (nombre_interes),
    CONSTRAINT chk_intereses_categoria CHECK (
        categoria IN ('Académico', 'Deporte', 'Tecnología', 'Cultura', 'Videojuegos', 'Otro')
    )
);

CREATE TABLE IF NOT EXISTS estudiante_intereses (
    id_estudiante INT NOT NULL,
    id_interes INT NOT NULL,
    nivel_dominio VARCHAR(20) NOT NULL DEFAULT 'Interesado',
    CONSTRAINT pk_estudiante_intereses PRIMARY KEY (id_estudiante, id_interes),
    CONSTRAINT fk_est_int_estudiante FOREIGN KEY (id_estudiante)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_est_int_interes FOREIGN KEY (id_interes)
        REFERENCES intereses_habilidades (id_interes)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_nivel_dominio CHECK (
        nivel_dominio IN ('Interesado', 'Principiante', 'Intermedio', 'Avanzado', 'Mentor')
    )
);

CREATE TABLE IF NOT EXISTS conexiones (
    id_seguidor INT NOT NULL,
    id_seguido INT NOT NULL,
    tipo_conexion VARCHAR(20) NOT NULL DEFAULT 'Seguimiento',
    estado VARCHAR(20) NOT NULL DEFAULT 'Aceptada',
    fecha_conexion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_conexiones PRIMARY KEY (id_seguidor, id_seguido),
    CONSTRAINT fk_conexiones_seguidor FOREIGN KEY (id_seguidor)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_conexiones_seguido FOREIGN KEY (id_seguido)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_conexiones_distintos CHECK (id_seguidor <> id_seguido),
    CONSTRAINT chk_conexiones_tipo CHECK (tipo_conexion IN ('Seguimiento', 'Mentoría')),
    CONSTRAINT chk_conexiones_estado CHECK (estado IN ('Pendiente', 'Aceptada', 'Rechazada'))
);

CREATE TABLE IF NOT EXISTS grupos (
    id_grupo SERIAL,
    id_creador INT NOT NULL,
    nombre_grupo VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    tipo_grupo VARCHAR(30) NOT NULL,
    es_privado BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_creacion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_grupos PRIMARY KEY (id_grupo),
    CONSTRAINT uq_grupos_nombre UNIQUE (nombre_grupo),
    CONSTRAINT fk_grupos_creador FOREIGN KEY (id_creador)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT chk_grupos_tipo CHECK (
        tipo_grupo IN ('Grupo de Estudio', 'Hackatón', 'Club de Interés', 'Deportivo', 'Investigación')
    )
);

CREATE TABLE IF NOT EXISTS grupo_miembros (
    id_grupo INT NOT NULL,
    id_estudiante INT NOT NULL,
    rol_miembro VARCHAR(20) NOT NULL DEFAULT 'Miembro',
    fecha_union TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_grupo_miembros PRIMARY KEY (id_grupo, id_estudiante),
    CONSTRAINT fk_gm_grupo FOREIGN KEY (id_grupo)
        REFERENCES grupos (id_grupo)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_gm_estudiante FOREIGN KEY (id_estudiante)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_gm_rol CHECK (rol_miembro IN ('Administrador', 'Moderador', 'Miembro'))
);

CREATE TABLE IF NOT EXISTS publicaciones (
    id_publicacion SERIAL,
    id_autor INT NOT NULL,
    id_grupo INT,
    tipo_contenido VARCHAR(30) NOT NULL,
    contenido_texto TEXT NOT NULL,
    url_recurso VARCHAR(500),
    fecha_publicacion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_publicaciones PRIMARY KEY (id_publicacion),
    CONSTRAINT fk_publicaciones_autor FOREIGN KEY (id_autor)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_publicaciones_grupo FOREIGN KEY (id_grupo)
        REFERENCES grupos (id_grupo)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_publicaciones_tipo CHECK (
        tipo_contenido IN ('Pregunta de Tarea', 'Recurso Útil', 'Noticia Tecnológica', 'Meme', 'Anuncio')
    )
);

CREATE TABLE IF NOT EXISTS comentarios (
    id_comentario SERIAL,
    id_publicacion INT NOT NULL,
    id_autor INT NOT NULL,
    texto_comentario TEXT NOT NULL,
    fecha_comentario TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_comentarios PRIMARY KEY (id_comentario),
    CONSTRAINT fk_comentarios_publicacion FOREIGN KEY (id_publicacion)
        REFERENCES publicaciones (id_publicacion)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_comentarios_autor FOREIGN KEY (id_autor)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS eventos (
    id_evento SERIAL,
    id_organizador INT NOT NULL,
    id_grupo INT,
    titulo_evento VARCHAR(150) NOT NULL,
    descripcion TEXT NOT NULL,
    modalidad VARCHAR(20) NOT NULL,
    ubicacion_o_enlace VARCHAR(255) NOT NULL,
    cupo_maximo INT,
    fecha_inicio TIMESTAMPTZ NOT NULL,
    fecha_fin TIMESTAMPTZ NOT NULL,
    CONSTRAINT pk_eventos PRIMARY KEY (id_evento),
    CONSTRAINT fk_eventos_organizador FOREIGN KEY (id_organizador)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_eventos_grupo FOREIGN KEY (id_grupo)
        REFERENCES grupos (id_grupo)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT chk_eventos_modalidad CHECK (modalidad IN ('Presencial', 'Virtual', 'Híbrido')),
    CONSTRAINT chk_eventos_fechas CHECK (fecha_fin > fecha_inicio),
    CONSTRAINT chk_eventos_cupo CHECK (cupo_maximo IS NULL OR cupo_maximo > 0)
);

CREATE TABLE IF NOT EXISTS evento_asistentes (
    id_evento INT NOT NULL,
    id_estudiante INT NOT NULL,
    estado_asistencia VARCHAR(20) NOT NULL DEFAULT 'Confirmado',
    fecha_inscripcion TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_evento_asistentes PRIMARY KEY (id_evento, id_estudiante),
    CONSTRAINT fk_ea_evento FOREIGN KEY (id_evento)
        REFERENCES eventos (id_evento)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_ea_estudiante FOREIGN KEY (id_estudiante)
        REFERENCES estudiantes (id_estudiante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_ea_estado CHECK (estado_asistencia IN ('Confirmado', 'Interesado', 'Cancelado'))
);

TRUNCATE TABLE
    evento_asistentes, eventos, comentarios, publicaciones,
    grupo_miembros, grupos, conexiones, estudiante_intereses,
    intereses_habilidades, estudiantes, programas_academicos
RESTART IDENTITY CASCADE;

-- =============================================================================
-- 1. POBLACIÓN DE DATOS (DML - INSERT)
-- =============================================================================

INSERT INTO programas_academicos (nombre_programa, facultad) VALUES
('Tecnología en Desarrollo de Software', 'Facultad de Ingeniería'),
('Ingeniería de Software', 'Facultad de Ingeniería'),
('Ingeniería Eléctrica', 'Facultad de Ingeniería'),
('Diseño Gráfico Digital', 'Facultad de Producción y Diseño');

INSERT INTO estudiantes (id_programa, nombre_completo, correo_institucional, contrasena_hash, semestre_actual, biografia, disponible_mentoria) VALUES
(1, 'Alejandro Valencia Jiménez', 'alejandro.valencia@pascualbravo.edu.co', '$2b$12$HashAlejo01', 6, 'Mentor en Bases de Datos SQL, POO en C#, C++ y Angular.', TRUE),
(1, 'Miguel Ángel Restrepo',      'miguel.restrepo@pascualbravo.edu.co',    '$2b$12$HashMiguel02', 5, 'Desarrollador web Angular y entusiasta de algoritmos.', TRUE),
(2, 'Laura Sofía Gómez',          'laura.gomez@pascualbravo.edu.co',        '$2b$12$HashLaura03',  2, 'Aprendiendo modelado relacional y consultas SQL.', FALSE),
(3, 'Carlos Andrés Ríos',         'carlos.rios@pascualbravo.edu.co',        '$2b$12$HashCarlos04', 8, 'Investigador en IoT y redes eléctricas inteligentes.', TRUE),
(1, 'Valentina Morales Cano',     'valentina.morales@pascualbravo.edu.co',  '$2b$12$HashValen05',  1, 'Estudiante de primer semestre buscando mentoría en programación.', FALSE),
(2, 'Mateo Montoya Vélez',        'mateo.montoya@pascualbravo.edu.co',      '$2b$12$HashMateo06',  7, 'Competidor en maratones de programación C++.', TRUE);

INSERT INTO intereses_habilidades (nombre_interes, categoria) VALUES
('PostgreSQL y Diseño de Bases de Datos', 'Tecnología'),
('Programación en C# y .NET', 'Tecnología'),
('Estructuras de Datos en C++', 'Académico'),
('Desarrollo Frontend en Angular', 'Tecnología'),
('Polo Acuático', 'Deporte'),
('Fútbol Universitario', 'Deporte'),
('Slay the Spire & Estrategia', 'Videojuegos');

INSERT INTO estudiante_intereses (id_estudiante, id_interes, nivel_dominio) VALUES
(1, 1, 'Mentor'), (1, 2, 'Avanzado'), (1, 3, 'Avanzado'), (1, 4, 'Intermedio'), (1, 5, 'Avanzado'), (1, 7, 'Intermedio'),
(2, 4, 'Mentor'), (2, 1, 'Intermedio'), (2, 6, 'Avanzado'),
(3, 1, 'Principiante'), (3, 2, 'Interesado'),
(4, 3, 'Avanzado'),
(5, 2, 'Principiante'), (5, 1, 'Interesado'),
(6, 3, 'Mentor'), (6, 1, 'Avanzado');

INSERT INTO conexiones (id_seguidor, id_seguido, tipo_conexion, estado) VALUES
(3, 1, 'Mentoría', 'Aceptada'),
(5, 1, 'Mentoría', 'Aceptada'),
(2, 1, 'Seguimiento', 'Aceptada'),
(1, 2, 'Seguimiento', 'Aceptada'),
(3, 2, 'Mentoría', 'Aceptada'),
(5, 6, 'Mentoría', 'Pendiente');

INSERT INTO grupos (id_creador, nombre_grupo, descripcion, tipo_grupo, es_privado) VALUES
(1, 'Semillero de Bases de Datos Pascualino', 'Estudio de SQL, DML y Vistas en PostgreSQL.', 'Grupo de Estudio', FALSE),
(1, 'Equipo Hackatón RedUniConnect', 'Desarrollo de soluciones para el campus universitario.', 'Hackatón', FALSE),
(6, 'Club de Programación Competitiva C++', 'Entrenamiento para maratones de algoritmos.', 'Club de Interés', FALSE);

INSERT INTO grupo_miembros (id_grupo, id_estudiante, rol_miembro) VALUES
(1, 1, 'Administrador'), (1, 2, 'Moderador'), (1, 3, 'Miembro'), (1, 5, 'Miembro'),
(2, 1, 'Administrador'), (2, 2, 'Miembro'), (2, 4, 'Moderador'), (2, 6, 'Miembro'),
(3, 6, 'Administrador'), (3, 1, 'Moderador'), (3, 2, 'Miembro');

INSERT INTO publicaciones (id_autor, id_grupo, tipo_contenido, contenido_texto, url_recurso) VALUES
(1, 1, 'Recurso Útil', 'Guía de diseño de vistas SQL y uso de ALIAS semánticos.', 'https://github.com/Al3zxs/RedUniConnect'),
(3, 1, 'Pregunta de Tarea', '¿Cómo se diferencia un LEFT JOIN de un INNER JOIN al contar comentarios?', NULL),
(2, 2, 'Noticia Tecnológica', 'Lanzamiento de la Hackatón Pascualina 2026.', 'https://pascualbravo.edu.co/hackaton'),
(5, NULL, 'Meme', 'Cuando olvidas el WHERE en el DELETE pero tenías transacción abierta.', NULL);

INSERT INTO comentarios (id_publicacion, id_autor, texto_comentario) VALUES
(2, 1, 'Con INNER JOIN solo ves publicaciones que tienen al menos un comentario; con LEFT JOIN incluyes las que tienen 0 comentarios.'),
(2, 2, '¡Excelente explicación Alejo! Además puedes usar COALESCE o COUNT(c.id_comentario) para que devuelva 0.'),
(1, 3, 'Muchas gracias por el recurso, me sirvió mucho para la Tarea 5.');

INSERT INTO eventos (id_organizador, id_grupo, titulo_evento, descripcion, modalidad, ubicacion_o_enlace, cupo_maximo, fecha_inicio, fecha_fin) VALUES
(1, 1, 'Taller Práctico de Consultas DML y Vistas', 'Práctica en vivo con pgAdmin 4.', 'Presencial', 'Bloque 14 - Aula 302', 40, '2026-11-18 14:00:00-05', '2026-11-18 17:00:00-05'),
(1, 2, 'Hackatón Pascualina 2026', 'Competencia de 12 horas de desarrollo.', 'Híbrido', 'Auditorio Bloque B', 120, '2026-11-22 08:00:00-05', '2026-11-22 20:00:00-05');

INSERT INTO evento_asistentes (id_evento, id_estudiante, estado_asistencia) VALUES
(1, 1, 'Confirmado'), (1, 2, 'Confirmado'), (1, 3, 'Confirmado'), (1, 5, 'Confirmado'),
(2, 1, 'Confirmado'), (2, 2, 'Confirmado'), (2, 4, 'Confirmado'), (2, 6, 'Confirmado'), (2, 3, 'Interesado');

-- =============================================================================
-- 2. VISTAS ANALÍTICAS CON REGLAS DE NOMENCLATURA ALIAS (CREATE OR REPLACE VIEW)
-- =============================================================================

CREATE OR REPLACE VIEW vw_rel_perfil_integral_estudiante AS
SELECT
    e.id_estudiante AS codigo_estudiante,
    e.nombre_completo AS nombre_estudiante,
    p.nombre_programa AS carrera_estudiante,
    p.facultad AS facultad_adscrita,
    e.semestre_actual AS numero_semestre,
    e.disponible_mentoria AS indicador_mentor_activo,
    COUNT(DISTINCT ei.id_interes) AS total_intereses_habilidades,
    COUNT(DISTINCT c.id_seguidor) FILTER (WHERE c.tipo_conexion = 'Mentoría' AND c.estado = 'Aceptada') AS total_mentorizados_activos,
    COUNT(DISTINCT pub.id_publicacion) AS total_publicaciones_creadas,
    COUNT(DISTINCT com.id_comentario) AS total_comentarios_aportados
FROM estudiantes e
INNER JOIN programas_academicos p ON e.id_programa = p.id_programa
LEFT JOIN estudiante_intereses ei ON e.id_estudiante = ei.id_estudiante
LEFT JOIN conexiones c ON e.id_estudiante = c.id_seguido
LEFT JOIN publicaciones pub ON e.id_estudiante = pub.id_autor
LEFT JOIN comentarios com ON e.id_estudiante = com.id_autor
GROUP BY e.id_estudiante, e.nombre_completo, p.nombre_programa, p.facultad, e.semestre_actual, e.disponible_mentoria;

CREATE OR REPLACE VIEW vw_rel_actividad_eventos_cupos AS
SELECT
    ev.id_evento AS codigo_evento,
    ev.titulo_evento AS nombre_evento,
    COALESCE(g.nombre_grupo, 'Evento Institucional General') AS grupo_organizador,
    ev.modalidad AS modalidad_ejecucion,
    ev.cupo_maximo AS capacidad_maxima_autorizada,
    COUNT(ea.id_estudiante) FILTER (WHERE ea.estado_asistencia = 'Confirmado') AS total_asistentes_confirmados,
    (ev.cupo_maximo - COUNT(ea.id_estudiante) FILTER (WHERE ea.estado_asistencia = 'Confirmado')) AS cupos_disponibles_restantes,
    ROUND(
        (COUNT(ea.id_estudiante) FILTER (WHERE ea.estado_asistencia = 'Confirmado')::NUMERIC * 100.0)
        / NULLIF(ev.cupo_maximo, 0),
        2
    ) AS porcentaje_ocupacion_cupo_pct
FROM eventos ev
LEFT JOIN grupos g ON ev.id_grupo = g.id_grupo
LEFT JOIN evento_asistentes ea ON ev.id_evento = ea.id_evento
GROUP BY ev.id_evento, ev.titulo_evento, g.nombre_grupo, ev.modalidad, ev.cupo_maximo;

-- Consultas de verificación sobre las vistas
SELECT * FROM vw_rel_perfil_integral_estudiante ORDER BY total_mentorizados_activos DESC;
SELECT * FROM vw_rel_actividad_eventos_cupos ORDER BY porcentaje_ocupacion_cupo_pct DESC;

COMMIT;
